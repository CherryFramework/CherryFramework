frameworkShortcodeAtts={
	attributes:[
			{
				label:"Categories type",
				id:"type",
				help:"Categories of posts (e.g. \"portfolio\" or blank for post categories)."
			},
			{
				label:"List class",
				id:"class",
				help:"Enter list class (e.g. \"plus\", \"check\" or \"custom\")."
			}
	],
	defaultContent:"",
	shortcode:"categories"
};