<?php
	//includ js and css files
	include_once (CHERRY_PLUGIN_DIR . 'admin/include-style-script.php');
	
	//Shortcodes tinyMCE includes
	include_once (CHERRY_PLUGIN_DIR . 'admin/shortcodes/tinymce_shortcodes.php');