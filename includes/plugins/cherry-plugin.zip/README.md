cherry_plugin
=============



#### v1.1 ####

* Fix: import errors
* Add: blocking files on upload
* Fix: sorting errors
* Add: widgets rewrite 
* Add: widgets custom classes 
* Fix: shortcode Elastislide
* Add: styleswitcher
* Add: plugin-under-construction-content rewrite in child theme
* Add: plugin updater
* Add: intagram widget
* Upd: social widget 
* Fix: fixes in social network widget
* Add: banner widget
* Upd: improvements in wpml-compatibility