<?php
	//Widget
	include_once (CHERRY_PLUGIN_DIR . '/includes/widgets/register-widgets.php');
	include_once (CHERRY_PLUGIN_DIR . '/includes/widgets/widgets-manager.php');